

import Product from "./Product.js"
import multiply, {multiply, doUpper, sayHi } from "./mylib.js"

let obj = new Product("pendrive",240,"sandisk")
obj.show()

sayHi("prachi")
doUpper("hello")
multiply(12,13)
divide(24,2)